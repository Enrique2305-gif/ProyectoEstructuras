/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practica_poryecto;

/**
 *
 * @author CltControl
 */
public class Practica_Poryecto {

    public static void main(String[] args) {
        Tablero tb = new Tablero();
        tb.mostrar();
    }
}
