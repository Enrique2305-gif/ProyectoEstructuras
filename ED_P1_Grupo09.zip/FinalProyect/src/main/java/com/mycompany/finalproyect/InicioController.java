/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.finalproyect;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
/**
 * FXML Controller class
 *
 * @author David
 */
public class InicioController implements Initializable {


    @FXML
    private ImageView HumanPC;
    @FXML
    private ImageView HumanHuman;
    
     @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

     @FXML
    private void handleHumanPCClick(MouseEvent event) {
        try {
            App.setRoot("game");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }  
    
    public void handleHumanHuman(MouseEvent event) {
        try {
            App.setRoot("GameH");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }  
    
}
