/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.finalproyect;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import modulo.Proyecto_SinInterfaz;
import modulo.Tablero;
import modulo.Tree;
/**
 * FXML Controller class
 *
 * @author David
 */
public class GameController implements Initializable {

    @FXML
    private ImageView B00;
    @FXML
    private ImageView B01;
    @FXML
    private ImageView B02;
    @FXML
    private ImageView B10;
    @FXML
    private ImageView B11;
    @FXML
    private ImageView B12;
    @FXML
    private ImageView B20;
    @FXML
    private ImageView B21;
    @FXML
    private ImageView B22;
    @FXML
    private ImageView Back;
    
    private Image  circulo = new Image("img/circulo1.png");
    private Image  equis = new Image("img/equis1.png");
    
    private Proyecto_SinInterfaz pr = new Proyecto_SinInterfaz('O','X');
    Tablero tablero = new Tablero(pr.getComputerPlayer());
    Tree arbol = new Tree(tablero);
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Asignamos los eventos de clic a cada ImageView
        B00.setOnMouseClicked(event -> ChanceO(B00));
        B01.setOnMouseClicked(event -> ChanceO(B01));
        B02.setOnMouseClicked(event -> ChanceO(B02));
        B10.setOnMouseClicked(event -> ChanceO(B10));
        B11.setOnMouseClicked(event -> ChanceO(B11));
        B12.setOnMouseClicked(event -> ChanceO(B12));
        B20.setOnMouseClicked(event -> ChanceO(B20));
        B21.setOnMouseClicked(event -> ChanceO(B21));
        B22.setOnMouseClicked(event -> ChanceO(B22));
    }   
    
    @FXML
    private void BackInicio(MouseEvent event) {
        try {
            App.setRoot("Inicio");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void ChanceO(ImageView imageView){
        if(!(arbol.getRaiz().getContent().esEmpate() || arbol.getRaiz().getContent().verificarGanador())){
        imageView.setImage(circulo);
        String imageName = imageView.getId();
        String lastTwo = imageName.substring(imageName.length() - 2);
        int fila = Character.getNumericValue(lastTwo.charAt(0)); 
        int columna = Character.getNumericValue(lastTwo.charAt(1)); 
        arbol.getRaiz().getContent().setCasilla(fila, columna, pr.getHumanPlayer());
        //le toca a la maquina
        boolean ganaHumano= true;
        if(!(arbol.getRaiz().getContent().esEmpate() || arbol.getRaiz().getContent().verificarGanador())){
        arbol.getRaiz().generarPosiblesEstados(2);
        
        
        for(Tree hijo : arbol.getRaiz().getHijos()){
            hijo.imprimirArbol();
            hijo.getRaiz().MenorUtilidad();
            
            System.out.println("Utilidad 2da gen: "+hijo.getRaiz().getContent().getUtilidad());
        }

        Tree seleccionado = new Tree(arbol.getRaiz().MayorUtilidad().getRaiz().getContent());
        String indice = compararTableros(arbol.getRaiz().getContent(),seleccionado.getRaiz().getContent());
        ChanceX(indice);
        
        arbol = arbol.getRaiz().MayorUtilidad();
        arbol.getRaiz().borrarHijos();
        arbol.getRaiz().getContent().cambiarTurno();
        arbol.imprimirArbol();
        ganaHumano = false;
        }
        if(arbol.getRaiz().getContent().esEmpate()){
            System.out.println("Empate");
            Empate();
        }else if(arbol.getRaiz().getContent().verificarGanador()){
            if(ganaHumano){
                System.out.println("Has ganado");
                WinHuman();
            }else{
                System.out.println("La maquina Gano");
                WinIA();
            }
        }
        }    
   
    }
    
    
    private void ChanceX(String id) {
        // Usamos un switch para seleccionar la ImageView correcta
        switch (id) {
            case "B00":
                B00.setImage(equis);
                break;
            case "B01":
                B01.setImage(equis);
                break;
            case "B02":
                B02.setImage(equis);
                break;
            case "B10":
                B10.setImage(equis);
                break;
            case "B11":
                B11.setImage(equis);
                break;
            case "B12":
                B12.setImage(equis);
                break;
            case "B20":
                B20.setImage(equis);
                break;
            case "B21":
                B21.setImage(equis);
                break;
            case "B22":
                B22.setImage(equis);
                break;
            default:
                System.out.println("ID no válido");
                break;
        }
    }
    
    public static String compararTableros(Tablero tablero1, Tablero tablero2) {
        StringBuilder resultado = new StringBuilder();
        
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (tablero1.getCasilla(i, j) != tablero2.getCasilla(i, j)) {
                    resultado.append('B');
                    resultado.append(i);
                    resultado.append(j);
                }
            }
        }
        
        return resultado.toString();
    }
    
    private void WinHuman(){
        Alert mensaje = new Alert(Alert.AlertType.INFORMATION);
        mensaje.setTitle("Winner");
        mensaje.setContentText("¡Ganaste! ¡Qué jugada épica! Has vencido al tablero. ¿Te atreves a enfrentarte de nuevo?");
        mensaje.showAndWait();
    }
    
    private void Empate(){
        Alert mensaje = new Alert(Alert.AlertType.INFORMATION);
        mensaje.setTitle("Empate");
        mensaje.setContentText("¡Es un empate! Ambos jugaron bien, pero nadie logró hacerse con la victoria. ¿Listo para otro desafío? ");
        mensaje.showAndWait();
    }
    
    private void WinIA(){
        Alert mensaje = new Alert(Alert.AlertType.INFORMATION);
        mensaje.setTitle("Winner");
        mensaje.setContentText("¡La máquina te ha vencido! Pero no te preocupes, ¡próxima vez será diferente! ¿Preparado para la revancha?");
        mensaje.showAndWait();
    }
}
