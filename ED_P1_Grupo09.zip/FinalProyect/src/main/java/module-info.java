module com.mycompany.finalproyect {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.mycompany.finalproyect to javafx.fxml;
    exports com.mycompany.finalproyect;
}
