/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modulo;

/**
 *
 * @author David
 */
public class Tablero {
    private char[][] tablero;
    private char turno;
    private int utilidad;

    // Constructor para inicializar el tablero vacío
    public Tablero(char turno) {
        tablero = new char[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                tablero[i][j] = '-'; // Inicializamos con espacios vacíos
            }
        }
        this.turno = turno; // Empieza el jugador X
    }

    // Método para mostrar el tablero
    public void mostrar() {
        System.out.println( "Turno: "+turno);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(tablero[i][j]);
                if (j < 2) System.out.print(" | ");
            }
            System.out.println();
            if (i < 2) System.out.println("---------");
        }
        System.out.println();
    }
    
    public boolean esEmpate() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (tablero[i][j] == '-') {
                    return false; // Hay una casilla vacía, por lo que no es empate
                }
            }
        }
        return true; // No hay casillas vacías, es empate
    }
    
    public boolean verificarGanador() {
        // Comprobamos las filas
        for (int i = 0; i < 3; i++) {
            if (tablero[i][0] != '-' && tablero[i][0] == tablero[i][1] && tablero[i][1] == tablero[i][2]) {
                return true;
            }
        }    
        // Comprobamos las columnas
        for (int j = 0; j < 3; j++) {
            if (tablero[0][j] != '-' && tablero[0][j] == tablero[1][j] && tablero[1][j] == tablero[2][j]) {
                return true;
            }
        }
        // Comprobamos las diagonales
        if (tablero[0][0] != '-' && tablero[0][0] == tablero[1][1] && tablero[1][1] == tablero[2][2]) {
            return true;
        }
        if (tablero[0][2] != '-' && tablero[0][2] == tablero[1][1] && tablero[1][1] == tablero[2][0]) {
            return true;
        }
        return false; // Si no hay ganador
    }
    
    // Getter y setter para el tablero y turno
    public char getCasilla(int fila, int columna) {
        return tablero[fila][columna];
    }

    public void setCasilla(int fila, int columna, char simbolo) {
        tablero[fila][columna] = simbolo;
    }
    public char getTurno() {
        return turno;
    }
    public void cambiarTurno() {
        // Si el turno actual es 'X', lo cambiamos a 'O', y viceversa
        if (turno == 'X') {
            turno = 'O'; // Cambiar el turno a 'O'
        } else {
            turno = 'X'; // Cambiar el turno a 'X'
        }
    }
    
    
    public void calcularUtilidad(char Maquina) {
        int utilidadX = 0;
        int utilidadO = 0;
        // Comprobar filas
        if(this.verificarGanador()){
            this.utilidad = -5;
        }else{
            for (int i = 0; i < 3; i++) {
                boolean xPuedeGanar = true;
                boolean oPuedeGanar = true;

                for (int j = 0; j < 3; j++) {
                    if (tablero[i][j] == 'O') {
                        xPuedeGanar = false;
                    }
                    if (tablero[i][j] == 'X') {
                        oPuedeGanar = false;
                    }
                }
                
                if (xPuedeGanar) utilidadX++;
                if (oPuedeGanar) utilidadO++;
            }
            // Comprobar columnas
            for (int j = 0; j < 3; j++) {
                boolean xPuedeGanar = true;
                boolean oPuedeGanar = true;

                for (int i = 0; i < 3; i++) {
                    if (tablero[i][j] == 'O') {
                        xPuedeGanar = false;
                    }
                    if (tablero[i][j] == 'X') {
                        oPuedeGanar = false;
                    }
                }
                

                if (xPuedeGanar) utilidadX++;
                if (oPuedeGanar) utilidadO++;
            }
            // Comprobar diagonales  
            boolean xPuedeGanarDiag1 = true;
            boolean oPuedeGanarDiag1 = true;
            boolean xPuedeGanarDiag2 = true;
            boolean oPuedeGanarDiag2 = true;
            for (int i = 0; i < 3; i++) {
                if (tablero[i][i] == 'O') {
                    xPuedeGanarDiag1 = false;
                }
                if (tablero[i][i] == 'X') {
                    oPuedeGanarDiag1 = false;
                }

                if (tablero[i][2 - i] == 'O') {
                    xPuedeGanarDiag2 = false;
                }
                if (tablero[i][2 - i] == 'X') {
                    oPuedeGanarDiag2 = false;
                }
            }
            
            if (xPuedeGanarDiag1) utilidadX++;
            if (oPuedeGanarDiag1) utilidadO++;
            if (xPuedeGanarDiag2) utilidadX++;
            if (oPuedeGanarDiag2) utilidadO++;
            // Calcular utilidad
            if(Maquina == 'O'){
            this.utilidad = utilidadX - utilidadO;
            }else{
                this.utilidad = utilidadO - utilidadX;
            }
        }
    }

    public void setUtilidad(int utilidad) {
        this.utilidad = utilidad;
    }
    

    public int getUtilidad() {
        return utilidad;
    }
    
    public int validateTwoOAndSpace(char turno, char Acomparar) {
        // Verificar filas
        int count = 0;
        for (int i = 0; i < 3; i++) {
            if (checkLine(tablero[i][0], tablero[i][1], tablero[i][2],turno, Acomparar)) count++;
        }

        // Verificar columnas
        for (int i = 0; i < 3; i++) {
            if (checkLine(tablero[0][i], tablero[1][i], tablero[2][i],turno, Acomparar)) count++;
        }

        // Verificar diagonales
        if (checkLine(tablero[0][0], tablero[1][1], tablero[2][2],turno, Acomparar)) count++;
        if (checkLine(tablero[0][2], tablero[1][1], tablero[2][0],turno, Acomparar)) count++;

        return count;
    }
    
    public char OpuestoTurn() {
        // Si el turno actual es 'X', lo cambiamos a 'O', y viceversa
        char OpTurn;
        if (turno == 'X') {
            OpTurn = 'O'; // Cambiar el turno a 'O'
        } else {
            OpTurn = 'X'; // Cambiar el turno a 'X'
        }
        return OpTurn;
    }

    private boolean checkLine(char a, char b, char c, char turno, char Acomparar) {
        //System.out.println(this.OpuestoTurn());
        // Verificar si hay dos 'O/X' y un espacio en cualquier orden
        return (a == turno && b == turno && c == Acomparar) ||
               (a == turno && b == Acomparar && c == turno) ||
               (a == Acomparar && b == turno && c == turno);
    }
    
}
