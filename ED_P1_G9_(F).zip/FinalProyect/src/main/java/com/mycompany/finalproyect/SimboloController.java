/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.finalproyect;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author David
 */
public class SimboloController implements Initializable {
    
    @FXML
    private ImageView equis;
    @FXML
    private ImageView circulo;
   
    private String simboloSeleccionado;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        equis.setOnMouseClicked(event -> seleccionarSimbolo("X"));
        circulo.setOnMouseClicked(event -> seleccionarSimbolo("O"));
    }

    private void seleccionarSimbolo(String simbolo) {
        simboloSeleccionado = simbolo; // Guardar el símbolo seleccionado
        //System.out.println("Símbolo seleccionado: " + simboloSeleccionado); // Para pruebas

        // Cerrar la ventana actual
        Stage stage = (Stage) equis.getScene().getWindow();
        stage.close();
    }

    public String getSimboloSeleccionado() {
        return simboloSeleccionado;
    }
    
}
