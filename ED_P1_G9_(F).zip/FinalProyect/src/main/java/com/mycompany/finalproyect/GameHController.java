/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.finalproyect;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import modulo.Proyecto_SinInterfaz;
import modulo.Tablero;
import modulo.Tree;

/**
 * FXML Controller class
 *
 * @author David
 */
public class GameHController implements Initializable {

    @FXML
    private ImageView B00;
    @FXML
    private ImageView B01;
    @FXML
    private ImageView B02;
    @FXML
    private ImageView B10;
    @FXML
    private ImageView B11;
    @FXML
    private ImageView B12;
    @FXML
    private ImageView B20;
    @FXML
    private ImageView B21;
    @FXML
    private ImageView B22;
    @FXML
    private ImageView Back;

    private Image  circulo = new Image("img/circulo1.png");
    private Image  equis = new Image("img/equis1.png");
    
    private Proyecto_SinInterfaz pr = new Proyecto_SinInterfaz('O','X');
    Tablero tablero = new Tablero(pr.getComputerPlayer());
    Tree arbol = new Tree(tablero);
    
    private char currentPlayer = 'X';
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        B00.setOnMouseClicked(event -> ChanceO(B00));
        B01.setOnMouseClicked(event -> ChanceO(B01));
        B02.setOnMouseClicked(event -> ChanceO(B02));
        B10.setOnMouseClicked(event -> ChanceO(B10));
        B11.setOnMouseClicked(event -> ChanceO(B11));
        B12.setOnMouseClicked(event -> ChanceO(B12));
        B20.setOnMouseClicked(event -> ChanceO(B20));
        B21.setOnMouseClicked(event -> ChanceO(B21));
        B22.setOnMouseClicked(event -> ChanceO(B22));
    } 
    
    
    private void ChanceO(ImageView imageView) {
        if(!(arbol.getRaiz().getContent().esEmpate() || arbol.getRaiz().getContent().verificarGanador())){
        // Solo cambia si la imagen aún no tiene un valor asignado
        if (imageView.getImage() != circulo && imageView.getImage() != equis) {
            if (currentPlayer == 'O') {
                imageView.setImage(circulo);
                currentPlayer = 'X'; // Cambia al jugador X
            } else {
                imageView.setImage(equis);
                currentPlayer = 'O'; // Cambia al jugador O
            }
        }
        String imageName = imageView.getId();
        String lastTwo = imageName.substring(imageName.length() - 2);
        int fila = Character.getNumericValue(lastTwo.charAt(0)); 
        int columna = Character.getNumericValue(lastTwo.charAt(1)); 
        arbol.getRaiz().getContent().setCasilla(fila, columna,currentPlayer);
        if(arbol.getRaiz().getContent().esEmpate()){
            System.out.println("Empate");
            Empate();
        }else if(arbol.getRaiz().getContent().verificarGanador()){
            if(currentPlayer=='X'){
                System.out.println("Ha Ganado");
                WinHumanO();
            }else{
                System.out.println("La maquina Gano");
                WinHumanX();
            }
        }
        }
    }

    @FXML
    private void BackInicio(MouseEvent event) {
        try {
            App.setRoot("Inicio");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void WinHumanX(){
        Alert mensaje = new Alert(Alert.AlertType.INFORMATION);
        mensaje.setTitle("Winner");
        mensaje.setContentText("¡Boom! ¡Jugador X acaba de ganar!");
        mensaje.showAndWait();
    }
    
    private void Empate(){
        Alert mensaje = new Alert(Alert.AlertType.INFORMATION);
        mensaje.setTitle("Empate");
        mensaje.setContentText("¡Es un empate! Ambos jugaron bien, pero nadie logró hacerse con la victoria. ¿Listo para otro desafío? ");
        mensaje.showAndWait();
    }
    
    private void WinHumanO(){
        Alert mensaje = new Alert(Alert.AlertType.INFORMATION);
        mensaje.setTitle("Winner");
        mensaje.setContentText("¡Oh sí! ¡Jugador O se lleva la victoria!");
        mensaje.showAndWait();
    }
    
}
