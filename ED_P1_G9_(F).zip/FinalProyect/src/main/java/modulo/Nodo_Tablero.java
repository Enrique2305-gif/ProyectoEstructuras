/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modulo;

import java.util.LinkedList;

/**
 *
 * @author David
 */
public class Nodo_Tablero {
    private Tablero content;
    private LinkedList<Tree> hijos = new LinkedList<>();
    
    public Nodo_Tablero() {
        this.content = null;
        this.hijos = null;
    }

    public Nodo_Tablero(Tablero content) {
        this.content = content;
    }

    public Tablero getContent() {
        return content;
    }

    public LinkedList<Tree> getHijos() {
        return hijos;
    }
    
    private Tablero copiarTablero(Tablero original) {
        Tablero copia = new Tablero(original.getTurno());
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                copia.setCasilla(i, j, original.getCasilla(i, j));
            }
        }
        return copia;
    }
    
    
    public void generarPosiblesEstados(int profundidadMaxima) {
        if (profundidadMaxima == 0) {
            return; // Condición de corte: si se alcanzó la profundidad máxima, termina.
        }
        //LinkedList<Tree> possibleStates = new LinkedList<>();
        //content.cambiarTurno(); 
        char turnoJugar = content.getTurno();//turno a jugar

        // Recorremos todas las casillas del tablero
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (content.getCasilla(i, j) == '-') { // Si la casilla está vacía
                    // Crear una copia del tablero actual
                    Tablero nuevoTablero = copiarTablero(content);
                    nuevoTablero.setCasilla(i, j, turnoJugar); // Colocar el símbolo del jugador
                    nuevoTablero.cambiarTurno(); // Cambiar el turno para el siguiente jugador

                    // Crear un nuevo subárbol para el nuevo tablero
                    Tree nuevoArbol = new Tree(nuevoTablero);
                    hijos.add(nuevoArbol); // Añadir el subárbol como hijo
                    
                    
                    if(profundidadMaxima == 1){
                        nuevoArbol.getRaiz().getContent().calcularUtilidad(content.getTurno());
                    }
                    nuevoArbol.getRaiz().generarPosiblesEstados(profundidadMaxima - 1 );
                    
                }
            }
        } 
    }
    
    public void MenorUtilidad(){
        if(content.verificarGanador()){
            content.setUtilidad(10);
        }else if(content.esEmpate()){
            content.setUtilidad(0);
        }else if(Crucial()){
            content.setUtilidad(5);
        }
        else {
              
            int MenorUtilidad = 11;
            for (Tree hijo : hijos) {
                if(hijo.getRaiz().Crucial()){
                    hijo.getRaiz().getContent().setUtilidad(-11);
                }
                if(MenorUtilidad > hijo.getRaiz().getContent().getUtilidad()){
                    MenorUtilidad = hijo.getRaiz().getContent().getUtilidad();
                }          
            }    
            content.setUtilidad(MenorUtilidad);
        }
        //content.mostrar();
    }
    public boolean Crucial(){
        boolean crucial = content.validateTwoOAndSpace(content.OpuestoTurn(),'-')>= 2 
                && content.validateTwoOAndSpace(content.getTurno(),'-') < 1;
        return crucial;
    }
    
    public Tree MayorUtilidad() {
        int MayorUtilidad = -10;  // Inicializamos con la utilidad del primer hijo
        Tree HijoMayor = new Tree(hijos.getFirst().getRaiz().getContent()); 

        for (Tree hijo : hijos) {
            //System.out.println(" a Restar "+ hijo.getRaiz().getContent().validateTwoOAndSpace(hijo.getRaiz().getContent().OpuestoTurn()
                    //, hijo.getRaiz().getContent().getTurno()));
           
            int resta = hijo.getRaiz().getContent().getUtilidad() - 
                    (hijo.getRaiz().getContent().validateTwoOAndSpace(hijo.getRaiz().getContent().OpuestoTurn()
                    , hijo.getRaiz().getContent().getTurno()));
            //System.out.println("Resta: "+resta);
            hijo.getRaiz().getContent().setUtilidad(resta);
            //System.out.println("uTILIDAD 1 GEN "+ hijo.getRaiz().getContent().getUtilidad());
            if (MayorUtilidad < hijo.getRaiz().getContent().getUtilidad()) {
                MayorUtilidad = hijo.getRaiz().getContent().getUtilidad();  // Actualizamos si encontramos una mayor utilidad
                HijoMayor = hijo;
                
            }
        }

        content.setUtilidad(MayorUtilidad);  // Asignamos la mayor utilidad al nodo padre
        return HijoMayor;
    }
    
    
    public void borrarHijos() {
        if (hijos != null) {
            hijos.clear(); // Vacía la lista de hijos
        }
    }

}
