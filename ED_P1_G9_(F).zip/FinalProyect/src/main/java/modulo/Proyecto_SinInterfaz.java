/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modulo;

import java.util.Scanner;

/**
 *
 * @author David
 */
public class Proyecto_SinInterfaz {
    private char humanPlayer; // Jugador humano
    private char computerPlayer; // Jugador computadora
    private Scanner sc = new Scanner(System.in);

    public Proyecto_SinInterfaz(char humanPlayer, char computerPlayer) {
        this.humanPlayer = humanPlayer;
        this.computerPlayer = computerPlayer;
    }
    
    

    public Proyecto_SinInterfaz(String human) {
        if (human.equals("X")) {
                this.humanPlayer = 'X';
                computerPlayer = 'O';
            } else if (human.equals("O")) {
                this.humanPlayer = 'O';
                computerPlayer = 'X';
            }
        
    }
    
    
    
    public void chooseSymbols() {
        String symbol;
        do {
            System.out.println("Elija su símbolo (X o O): ");
            symbol = sc.nextLine().toUpperCase();
            if (symbol.equals("X")) {
                humanPlayer = 'X';
                computerPlayer = 'O';
            } else if (symbol.equals("O")) {
                humanPlayer = 'O';
                computerPlayer = 'X';
            } else {
                System.out.println("Símbolo no válido. Por favor, elija 'X' o 'O'.");
            }
        } while (!symbol.equals("X") && !symbol.equals("O"));
    }

    public char getHumanPlayer() {
        return humanPlayer;
    }

    public char getComputerPlayer() {
        return computerPlayer;
    }

    public void setHumanPlayer(char humanPlayer) {
        this.humanPlayer = humanPlayer;
    }

    public void setComputerPlayer(char computerPlayer) {
        this.computerPlayer = computerPlayer;
    }
    
    
    public void obtenerJugadaHumano(Tablero tablero) {
        int jugada;
        boolean jugadaValida = false;
        // Convertimos el tablero a una lista de 0-8 para que el jugador seleccione
        while (!jugadaValida) {
            System.out.println("Elija una casilla entre 0 y 8 para su jugada:");
            tablero.mostrar(); // Muestra el tablero actual
            try {
                jugada = Integer.parseInt(sc.nextLine());
                if (jugada >= 0 && jugada <= 8) {
                    int fila = jugada / 3; // Convertir el número a la fila
                    int columna = jugada % 3; // Convertir el número a la columna

                    if (tablero.getCasilla(fila, columna) == '-') {
                        tablero.setCasilla(fila, columna, humanPlayer); // Coloca la jugada del jugador
                        jugadaValida = true;
                    } else {
                        System.out.println("¡Casilla ocupada! Elija otra.");
                    }
                } else {
                    System.out.println("Número inválido. Elija un número entre 0 y 8.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número.");
            }
        }
    }
    
    // Método para jugar el juego
    private void playTres() {
        // Crear el tablero
        Tablero tablero = new Tablero(computerPlayer);
        Tree arbol = new Tree(tablero);

        // Bucle principal del juego
        boolean gameOver = false;
        boolean isMachineTurn = true; // La máquina comienza

        while (!gameOver) {
            // Muestra el tablero actual

            if (isMachineTurn) {
                System.out.println("Turno de la máquina:");
                arbol.getRaiz().getContent().mostrar();
                
                
                arbol.getRaiz().generarPosiblesEstados(2);
                
                
                for(Tree hijo : arbol.getRaiz().getHijos()){
                    //int utility = hijo.getRaiz().getHijos().getFirst().getRaiz().getContent().getUtilidad();
                    //System.out.println("Utilidad hijos 2da gen: "+utility);
                    hijo.getRaiz().MenorUtilidad();
                    //System.out.println("Utilidad hijos 1ra Gen: "+hijo.getRaiz().getContent().getUtilidad());
                    //System.out.println();
                }
                arbol = arbol.getRaiz().MayorUtilidad();
                arbol.getRaiz().borrarHijos();
                //System.out.println("Arbol seleccionado");
                //arbol.getRaiz().getContent().mostrar();
                isMachineTurn = false;
            } else {
                System.out.println("Turno del jugador humano:");
                obtenerJugadaHumano(arbol.getRaiz().getContent()); // Obtener la jugada del humano
                arbol.getRaiz().getContent().cambiarTurno();
                isMachineTurn = true;
            }

            // Verificar si el juego termina
            if (arbol.getRaiz().getContent().verificarGanador()) {
                arbol.getRaiz().getContent().mostrar(); // Muestra el tablero final
                if (isMachineTurn) {
                    System.out.println("¡Felicidades, has ganado!");
                } else {
                    System.out.println("¡La máquina ha ganado!");
                }
                gameOver = true;
            } else if (arbol.getRaiz().getContent().esEmpate()) {
                arbol.getRaiz().getContent().mostrar(); // Muestra el tablero final
                System.out.println("¡Es un empate!");
                gameOver = true;
            }
        }
    }
/*
    public static void main(String[] args) {
        Proyecto_SinInterfaz pr = new Proyecto_SinInterfaz();
        pr.chooseSymbols();
        
//        Tablero tb = new Tablero(pr.getComputerPlayer()); 
//        
//        Tree t = new Tree(tb);
//        t.getRaiz().generarPosiblesEstados(2);
//        t.imprimirArbol();
//        
//        for(Tree hijo : t.getRaiz().getHijos()){
//            int utility = hijo.getRaiz().getHijos().getFirst().getRaiz().getContent().getUtilidad();
//            System.out.println("Utilidad hijos 2da gen: "+utility);
//            hijo.getRaiz().MenorUtilidad();
//            System.out.println("Utilidad hijos 1ra Gen: "+hijo.getRaiz().getContent().getUtilidad());
//            System.out.println();
//        }
//        
//        t = t.getRaiz().MayorUtilidad();
//        System.out.println("Utilidad Raiz: "+t.getRaiz().getContent().getUtilidad());
//        t.getRaiz().borrarHijos();
//        t.imprimirArbol();
//        
//        
//        pr.obtenerJugadaHumano(t.getRaiz().getContent());
//        t.getRaiz().getContent().mostrar();

        pr.playTres();
        
//        Tablero tb =new Tablero('O');
//        tb.setCasilla(0, 0,'X');
//        tb.setCasilla(1, 1,'X');
//        tb.setCasilla(1, 0,'X');
//        
//        tb.setCasilla(0,1,'O');
//        tb.setCasilla(2,2,'O');
//        
//        tb.mostrar();
//        System.out.println(tb.getTurno());
//        System.out.println(tb.validateTwoOAndSpace(tb.getTurno()));
//        System.out.println(tb.OpuestoTurn());
//        System.out.println(tb.validateTwoOAndSpace(tb.OpuestoTurn()));
   
   }*/
}
